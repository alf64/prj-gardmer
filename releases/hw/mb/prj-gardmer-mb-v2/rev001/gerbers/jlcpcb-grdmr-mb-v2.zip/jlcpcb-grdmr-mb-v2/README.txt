Board name:
grdmr-mb-v2

Board size
X: 147 mm
Y: 71 mm

Board thickness: 1.6 mm

Board number of copper layers: 2

Vias: Tented


Files info below

BOTTOM Copper:
grdmr-mb-v2-B_Cu.gbl

BOTTOM Soldermask:
grdmr-mb-v2-B_Mask.gbs

BOTTOM Silkscreen:
grdmr-mb-v2-B_Silkscreen.gbo

TOP Copper:
grdmr-mb-v2-F_Cu.gtl

TOP Soldermask:
grdmr-mb-v2-F_Mask.gts

TOP Silkscreen:
grdmr-mb-v2-F_Silkscreen.gto

Board outline:
grdmr-mb-v2-Edge_Cuts.gm1

Drill report file:
grdmr-mb-v2-drl.rpt

Plated holes drill file:
grdmr-mb-v2-PTH.drl

Plated holes drill map file:
grdmr-mb-v2-PTH-drl_map.gbr

Non-Plated holes drill file:
grdmr-mb-v2-NPTH.drl

Non-Plated holes drill map file:
grdmr-mb-v2-NPTH-drl_map.gbr
